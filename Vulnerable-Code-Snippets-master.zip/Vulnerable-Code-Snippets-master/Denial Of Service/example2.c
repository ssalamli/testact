int i;
char inLine[64];
cin >> inLine;
i = atoi (inLine);
sleep(i);
