<?php header(“Location: “.$_GET[“go”]); die();  ?>
